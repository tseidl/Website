The article "The Politics of Platform Capitalism. A Case Study on the Regulation of Uber in New York" comes with four supplementary files:

1) An online appendix that elaborates on some of the points in the main text.

2) A R script ("Politics of Platform Work_Replication Code.R") containing replication code for the figures presented in the paper and the online appendix. 

3) A RData file("Data.RData") which contains a data frame with information on the frames used (and on which Figure 2 and Figure 5 are based) and the corpus on which the sentiment analysis was done. 

4) A dna file ("Uber_NY.dna") which contains the results of the analysis and from which all other data can be extracted. It can also be opened with the software Discourse Network Analyser (for details, see  Leifeld, Philipp; Gruber, Johannes; Bosner, Felix Rolf: Discourse Network Analyzer Manual).